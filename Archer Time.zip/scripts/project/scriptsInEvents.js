

const scriptsInEvents = {

	async Fase1_Event20_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase1_Event21_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase1_Event27_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase1_Event31_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase1_Event34_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase1_Event44_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event19_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event22_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event23_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event26_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event33_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event43_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event52_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	},

	async Fase2_Event55_Act4(runtime, localVars)
	{
		let Vida = runtime.globalVars.Vida;
		Vida--;
		runtime.globalVars.Vida = Vida;
	}
};

self.C3.ScriptsInEvents = scriptsInEvents;
